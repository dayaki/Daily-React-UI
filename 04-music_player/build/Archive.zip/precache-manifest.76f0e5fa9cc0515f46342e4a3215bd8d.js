self.__precacheManifest = [
  {
    "revision": "64ab1ec28e389d4d1b38c660e14c6f10",
    "url": "/react-ui/04/static/media/heart.64ab1ec2.svg"
  },
  {
    "revision": "cb03e978ad2f105e179c",
    "url": "/react-ui/04/static/css/main.107cb661.chunk.css"
  },
  {
    "revision": "16c958bf9c6a71d6c3cf1edaa4de7007",
    "url": "/react-ui/04/static/media/shuffle.16c958bf.svg"
  },
  {
    "revision": "ef765b06f84fae751e69",
    "url": "/react-ui/04/static/js/1.ef765b06.chunk.js"
  },
  {
    "revision": "010c6b0a1412740732d0",
    "url": "/react-ui/04/static/js/runtime~main.010c6b0a.js"
  },
  {
    "revision": "f210f473776733bcfa512bdf72c01083",
    "url": "/react-ui/04/static/media/bigshaq.f210f473.jpg"
  },
  {
    "revision": "cb03e978ad2f105e179c",
    "url": "/react-ui/04/static/js/main.cb03e978.chunk.js"
  },
  {
    "revision": "a7afc9157fd2e445c7cd8a67b1e24fe7",
    "url": "/react-ui/04/static/media/play.a7afc915.svg"
  },
  {
    "revision": "bddd0db36e1c27ada1c949c1a35eeef7",
    "url": "/react-ui/04/static/media/pause.bddd0db3.svg"
  },
  {
    "revision": "d40ce09dfb07d26440d0394b7c951013",
    "url": "/react-ui/04/static/media/forward.d40ce09d.svg"
  },
  {
    "revision": "ded16a3eaecb51811238c76bc8f5f017",
    "url": "/react-ui/04/static/media/rewind.ded16a3e.svg"
  },
  {
    "revision": "ef765b06f84fae751e69",
    "url": "/react-ui/04/static/css/1.972dd883.chunk.css"
  },
  {
    "revision": "8b7f6129fcc7cfa022c63a0a588f06bc",
    "url": "/react-ui/04/index.html"
  }
];